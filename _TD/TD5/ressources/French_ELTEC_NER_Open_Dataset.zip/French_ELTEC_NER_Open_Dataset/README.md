French ELTEC NER Open Dataset

Authors: 
Carmen Brando, CRH-EHESS
Francesca Frontini, Istituto di Linguistica Computazionale “A. Zampolli” - Consiglio Nazionale delle Ricerche (ILC-CNR)
Ioana Galleron, Université Sorbonne Nouvelle, laboratoire Lattice - UMR 8094

Licence: CC-BY-SA 4.0

Excerpts of 100 texts of 19th French literature annotated in named entities relying on the categories listed below.
PERS
LOC
ORG
OTHER
WORK
DEMO
ROLE
EVENT

Size: 116225 tokens

In line with ELTEC guidelines created in this context:
Francesca Frontini, Carmen Brando, Joanna Byszuk, Ioana Galleron, Diana Santos, et al.. Named Entity Recognition for Distant Reading in ELTeC. CLARIN Annual Conference 2020, Oct 2020, Virtual Event, France. hal-03160438 
 
This dataset was annotated using Tagtog.com and lives in: https://www.tagtog.com/cvbrandoe/CostDREltecFrL2

This zip was generated on: 2022-11-11

The dataset is here written in the [anndoc format](https://docs.tagtog.com/anndoc.html). Use the `annotations-legend.json` file to help you interpret the annotations.

List of files and size of file in tokens:

FRA00101_Adam.txt	492
FRA00102_Adam.txt	364
FRA00201_Audoux.txt	701
FRA00301_Aimard.txt	973
FRA00302_Aimard.txt	315
FRA00401_Allais.txt	328
FRA00501_Balzac.txt	1163
FRA00502_Balzac.txt	4709
FRA00503_Balzac.txt	7751
FRA00601_Boisgobey.txt	813
FRA00602_Boisgobey.txt	433
FRA00701_Carraud.txt	1050
FRA00801_Dash.txt	803
FRA00901_Daudet.txt	1535
FRA01002_DelarueMardrus.txt	774
FRA01101_Dombre.txt	631
FRA01102_Dombre.txt	323
FRA01201_Feval.txt	572
FRA01202_Feval.txt	1020
FRA01203_Feval.txt	955
FRA01301_Flaubert.txt	856
FRA01302_Flaubert.txt	618
FRA01303_Flaubert.txt	1620
FRA01401_Fleuriot.txt	434
FRA01402_Fleuriot.txt	1098
FRA01403_Fleuriot.txt	213
FRA01501_France.txt	816
FRA01601_GautierJ.txt	636
FRA01602_GautierJ.txt	617
FRA01603_GautierJ.txt	1120
FRA01701_GautierT.txt	830
FRA01801_Gay.txt	1592
FRA01902_Gaboriau.txt	510
FRA02001_Gilbert.txt	598
FRA02101_Girardin.txt	532
FRA02201_Gouraud.txt	706
FRA02202_Gouraud.txt	502
FRA02203_Gouraud.txt	666
FRA02301_Greville.txt	830
FRA02302_Greville.txt	925
FRA02303_Greville.txt	784
FRA02401_LeRouge.txt	663
FRA02501_Loti.txt	802
FRA02601_Malot.txt	1672
FRA02602_Malot.txt	695
FRA02603_Malot.txt	1348
FRA02701_Maupassant.txt	1100
FRA02702_Maupassant.txt	669
FRA02802_Mirbeau.txt	552
FRA02901_Noailles.txt	580
FRA03001_Ohnet.txt	993
FRA03002_Ohnet.txt	388
FRA03003_Ohnet.txt	1822
FRA03101_Ponson.txt	216
FRA03201_Blandy.txt	1113
FRA03302_Rattazzi.txt	1543
FRA03401_Reybaud.txt	2505
FRA03601_Proust.txt	5901
FRA03701_Sand.txt	1374
FRA03702_Sand.txt	905
FRA03704_Sand.txt	3102
FRA03802_Stern.txt	803
FRA03903_Stolz.txt	1096
FRA04001_Verne.txt	1321
FRA04002_Verne.txt	993
FRA04102_Erckmann.txt	633
FRA04202_Rolland.txt	577
FRA04301_Achard.txt	1893
FRA04401_Barbusse.txt	574
FRA04501_Barres.txt	2362
FRA04601_Bazin.txt	1117
FRA04701_Bourget.txt	1984
FRA04801_Corday.txt	578
FRA04901_Dumas.txt	4155
FRA05101_Eekhoud.txt	895
FRA05201_Feuillet.txt	3019
FRA05301_Galopin.txt	405
FRA05401_Kock.txt	1755
FRA05501_Lermina.txt	648
FRA05602_Lesueur.txt	687
FRA05702_Maquet.txt	973
FRA05801_Mille.txt	658
FRA05901_Moselly.txt	850
FRA06001_Rebell.txt	1010
FRA06101_Sandeau.txt	3232
FRA06201_Viel-Castel.txt	1472
FRA06301_Montepin.txt	376
FRA06401_Chandeneux.txt	508
FRA06501_Gyp.txt	407
FRA06601_Peladan.txt	765
FRA06701_Uchard.txt	590
FRA06801_Vaillant.txt	1819
FRA06901_Vignon.txt	873
FRA07001_Mendes.txt	2252
FRA07101_Blondel.txt	1373
FRA07201_Montagne.txt	667
FRA07301_Valgand.txt	766
FRA07401_Leblanc.txt	549
FRA07501_Darien.txt	792
FRA07601_Leroux.txt	647
